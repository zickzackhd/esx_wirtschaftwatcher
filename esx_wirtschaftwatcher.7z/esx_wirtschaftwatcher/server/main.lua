ESX = nil
Config.SaveAfterRestart = false
TriggerEvent('FIVELIFERPDEZXN4OmdldFNoYXJlZE9iamVjdAZICKZACKHD', function(obj) ESX = obj end)

AddEventHandler('onResourceStart', function(resourceName)
    if Config.SaveAfterRestart then
        if (GetCurrentResourceName() ~= resourceName) then
        return
        end
        userbankkaufkraft=0
        userBarKaufkraft=0
        firmenkaufkraft=0
        blackmoneyKaufkraft=0
        MySQL.ready(function()        
        MySQL.Async.fetchAll('SELECT * FROM users',{},function(AllUser)
	
            RunUSERWirschaftspruefung(AllUser)
        end)
        MySQL.Async.fetchAll('SELECT * FROM addon_account_data',{},function(AllFirmen)
           
            RunFirmenWirtschaftspruefung(AllFirmen)
        end)

    end)
    Citizen.Wait(5000)
    MySQL.Sync.execute("INSERT INTO wirtschaft (bank, bargeld, firmengeld, blackmoney) VALUES (@bank, @bargeld, @firmengeld, @blackmoney)",{['@bank'] = userbankkaufkraft,['@bargeld'] = userBarKaufkraft,['@firmengeld'] = firmenkaufkraft,['@blackmoney'] = blackmoneyKaufkraft})
    print("Mannuelles Speichern Erfogreich")
    end
end)
  
  

AddEventHandler('txAdmin:events:scheduledRestart', function(eventData)
if eventData.secondsRemaining == 1800 then
userbankkaufkraft=0
userBarKaufkraft=0
firmenkaufkraft=0
blackmoneyKaufkraft=0
    MySQL.ready(function()        
        MySQL.Async.fetchAll('SELECT * FROM users',{},function(AllUser)
	
            RunUSERWirschaftspruefung(AllUser)
        end)
        MySQL.Async.fetchAll('SELECT * FROM addon_account_data',{},function(AllFirmen)
           
            RunFirmenWirtschaftspruefung(AllFirmen)
        end)

    end)
    Citizen.Wait(5000)
    MySQL.Sync.execute("INSERT INTO wirtschaft (bank, bargeld, firmengeld, blackmoney) VALUES (@bank, @bargeld, @firmengeld, @blackmoney)",{['@bank'] = userbankkaufkraft,['@bargeld'] = userBarKaufkraft,['@firmengeld'] = firmenkaufkraft,['@blackmoney'] = blackmoneyKaufkraft})
  
end 
end)


function RunUSERWirschaftspruefung(AllUser)
    for i=1 , #AllUser,1 do 

        decode = json.decode(AllUser[i].accounts)

        if decode.money ~=nil then
            if decode.money >0 then
            
                userBarKaufkraft= userBarKaufkraft+decode.money
            else
             
            end
        end
        if decode.bank ~=nil then
            if decode.bank >0 then
            
                userbankkaufkraft= userbankkaufkraft+decode.bank
            else
             
            end
        end
       
        
    end


end
function RunFirmenWirtschaftspruefung(AllFirmen)
    for i=1 , #AllFirmen,1 do
        if string.match(AllFirmen[i].account_name, "society") then
            if string.match(AllFirmen[i].account_name, "cardealer") or string.match(AllFirmen[i].account_name, "police") or string.match(AllFirmen[i].account_name, "Justiz") or string.match(AllFirmen[i].account_name, "sgpolice") or string.match(AllFirmen[i].account_name, "ambulance") or string.match(AllFirmen[i].account_name, "fbi") or string.match(AllFirmen[i].account_name, "sheriff") or string.match(AllFirmen[i].account_name, "army") or string.match(AllFirmen[i].account_name, "swat") or string.match(AllFirmen[i].account_name, "news") or string.match(AllFirmen[i].account_name, "taxi") or string.match(AllFirmen[i].account_name, "Rathaus") or string.match(AllFirmen[i].account_name, "realestateagent") then

            else
               
                firmenkaufkraft=firmenkaufkraft+AllFirmen[i].money 
            end
        
    
        elseif  string.match(AllFirmen[i].account_name, "black_money") then
            blackmoneyKaufkraft= blackmoneyKaufkraft+AllFirmen[i].money 
        end
       
        
    end
end